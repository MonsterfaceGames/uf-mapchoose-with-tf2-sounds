using System.Collections.Concurrent;
using System.Net.Http;
using System.Text.Json;
using CS2MenuManager.API.Class;
using CS2MenuManager.API.Enum;
using CS2MenuManager.API.Menu;
using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Modules.Commands;
using CounterStrikeSharp.API.Modules.Cvars;
using CounterStrikeSharp.API.Modules.Timers;
using Microsoft.Extensions.Logging;

namespace UfMapchoose;

public record MapInfo(string MapName, string WorkshopId);

public class PluginConfig
{
    public float VoteStartTime { get; set; } = 3.0f;
    public bool AllowExtend { get; set; } = true;
    public float ExtendTimeStep { get; set; } = 10.0f;
    public int ExtendLimit { get; set; } = 3;
    public int ExcludeMaps { get; set; } = 0;
    public int IncludeMaps { get; set; } = 5;
    public bool IncludeCurrent { get; set; } = false;
    public float VoteDuration { get; set; } = 15.0f;
    public bool IgnoreSpec { get; set; } = true;
    public bool AllowRtv { get; set; } = true;
    public float RTVPercent { get; set; } = 0.6f;
    public float RTVDelay { get; set; } = 3.0f;
    public bool EnforceTimeLimit { get; set; } = true;
    public bool ChangeMapAfterRoundEnd { get; set; } = true;
    public string DefaultLanguage { get; set; } = "en";
}

public class UfMapchoose : BasePlugin
{
    public override string ModuleName => "uf-mapchoose";
    public override string ModuleVersion => "2.0V";
    public override string ModuleAuthor => "monsterfacegames";
    public override string ModuleDescription => "mapchoose plugin for uf server";

    private PluginConfig _cfg = new();

    private List<MapInfo> _mapList = new();
    private readonly Dictionary<ulong, string> _nominations = new();
    private readonly HashSet<ulong> _rtvVotes = new();
    private bool _voteInProgress;
    private bool _preVoteInProgress;
    private bool _mapChangePending;
    private bool _rtvEnabled;
    private DateTime _rtvEnabledAt;
    private int _extendCount;

    private List<MapInfo> _voteOptions = new();
    private readonly Dictionary<ulong, int> _playerVotes = new();
    private CounterStrikeSharp.API.Modules.Timers.Timer? _voteTimer;
    private CounterStrikeSharp.API.Modules.Timers.Timer? _preVoteTimer;
    private int _voteTimeLeft;
    private int _preVoteTimeLeft;
    private MapInfo? _pendingWinner;

    private readonly Queue<string> _recentMaps = new();
    private FileSystemWatcher? _configWatcher;
    private readonly Dictionary<ulong, int> _nominatePages = new();
    private bool _voteTimeElapsed;
    private bool _isRtvVote;

    private static readonly HttpClient _httpClient = new();
    private readonly ConcurrentDictionary<ulong, string> _playerLanguages = new();

    private static readonly Dictionary<string, string> CountryToLanguage = new()
    {
        { "DE", "de" },
        { "FR", "fr" },
        { "NL", "nl" },
        { "PT", "pt" },
        { "JP", "jp" },
        { "ES", "sp" },
        { "RU", "ru" },
    };

    // TF2 sounds from workshop addon ID 3720959150
    // Server must have workshop ID 3720959150 loaded for these sounds to work
    private const string WorkshopId = "3720959150";

    private static readonly List<string> SoundFiles = new()
    {
        "sounds/tf2/announcer_dec_missionbegins60s03.vsnd",
        "sounds/tf2/announcer_dec_missionbegins30s01.vsnd",
        "sounds/tf2/announcer_dec_missionbegins10s01.vsnd",
        "sounds/tf2/announcer_begins_5sec.vsnd",
        "sounds/tf2/announcer_begins_4sec.vsnd",
        "sounds/tf2/announcer_begins_3sec.vsnd",
        "sounds/tf2/announcer_begins_2sec.vsnd",
        "sounds/tf2/announcer_begins_1sec.vsnd",
        "sounds/tf2/vote_started.vsnd",
        "sounds/tf2/vote_success.vsnd",
        "sounds/tf2/vote_failure.vsnd"
    };

    private static readonly Dictionary<int, string> PreVoteSounds = new()
    {
        { 60, "sounds/tf2/announcer_dec_missionbegins60s03.vsnd" },
        { 30, "sounds/tf2/announcer_dec_missionbegins30s01.vsnd" },
        { 10, "sounds/tf2/announcer_dec_missionbegins10s01.vsnd" },
        {  5, "sounds/tf2/announcer_begins_5sec.vsnd" },
        {  4, "sounds/tf2/announcer_begins_4sec.vsnd" },
        {  3, "sounds/tf2/announcer_begins_3sec.vsnd" },
        {  2, "sounds/tf2/announcer_begins_2sec.vsnd" },
        {  1, "sounds/tf2/announcer_begins_1sec.vsnd" },
    };
    private const string SoundVoteStarted = "sounds/tf2/vote_started.vsnd";
    private const string SoundVoteSuccess = "sounds/tf2/vote_success.vsnd";
    private const string SoundVoteFailure = "sounds/tf2/vote_failure.vsnd";

    private static class Tr
    {
        public const string RtvAvailable = "rtv_available";
        public const string VoteInProgress = "vote_in_progress";
        public const string MapChangePending = "map_change_pending";
        public const string NoMapsConfigured = "no_maps_configured";
        public const string MapNotFound = "map_not_found";
        public const string NominateBroadcast = "nominate_broadcast";
        public const string NominateHeader = "nominate_header";
        public const string InvalidSelection = "invalid_selection";
        public const string LastPage = "last_page";
        public const string FirstPage = "first_page";
        public const string NominateClosed = "nominate_closed";
        public const string RtvDisabled = "rtv_disabled";
        public const string RtvWait = "rtv_wait";
        public const string RtvAlreadyVoted = "rtv_already_voted";
        public const string RtvBroadcast = "rtv_broadcast";
        public const string RtvNotVoted = "rtv_not_voted";
        public const string RtvCancelled = "rtv_cancelled";
        public const string NoVoteActive = "no_vote_active";
        public const string CurrentVote = "current_vote";
        public const string NoVoteYet = "no_vote_yet";
        public const string NextMap = "next_map";
        public const string VoteInProgressHeader = "vote_in_progress_header";
        public const string NoMapPending = "no_map_pending";
        public const string VotedFor = "voted_for";
        public const string ChangedVote = "changed_vote";
        public const string NoMapsAvailable = "no_maps_available";
        public const string VoteStarted = "vote_started";
        public const string VoteEndsIn = "vote_ends_in";
        public const string VoteFailedNoVotes = "vote_failed_no_votes";
        public const string MapWon = "map_won";
        public const string VoteResult = "vote_result";
        public const string MapExtended = "map_extended";
        public const string ChangeAfterRound = "change_after_round";
        public const string MapChangeTimeout = "map_change_timeout";
        public const string MapChangeSoon = "map_change_soon";
        public const string PreVoteStart = "pre_vote_start";
        public const string VoteStartsIn = "vote_starts_in";
        public const string ListMapsHeader = "list_maps_header";
        public const string ChangemapUsage = "changemap_usage";
        public const string AdminChangemap = "admin_changemap";
        public const string VoteResultWithVotes = "vote_result_with_votes";
        public const string VoteResultNoVotes = "vote_result_no_votes";
    }

    private readonly Dictionary<string, Dictionary<string, string>> _translations = new();

     private string TrMsg(string key, string lang, params object[] args)
     {
         if (_translations.TryGetValue(lang, out var translations))
         {
             if (translations.TryGetValue(key, out var msg))
                 return args.Length > 0 ? string.Format(msg, args) : msg;
         }
         if (_translations.TryGetValue(_cfg.DefaultLanguage, out var fallback))
         {
             if (fallback.TryGetValue(key, out var msg))
                 return args.Length > 0 ? string.Format(msg, args) : msg;
         }
         return args.Length > 0 ? string.Format(key, args) : key;
     }

     public override void Load(bool hotReload)
    {
        LoadConfig();
        LoadTranslations();
        LoadMapList();
        LoadRecentMaps();

        RegisterEventHandler<EventPlayerDisconnect>(OnPlayerDisconnect, HookMode.Post);
        RegisterEventHandler<EventRoundEnd>(OnRoundEnd, HookMode.Post);
        RegisterEventHandler<EventRoundStart>(OnRoundStart, HookMode.Post);
        RegisterEventHandler<EventMapShutdown>(OnMapShutdown, HookMode.Post);
        RegisterEventHandler<EventPlayerConnectFull>(OnPlayerConnectFull, HookMode.Post);

        for (int i = 1; i <= 9; i++)
        {
            int idx = i;
            AddCommand($"css_{idx}", "Cast map vote or nominate", (player, _) => HandleNumberCommand(player, idx));
        }

        AddCommand("css_workshoplistmaps", "List all workshop maps from maplist", (player, _) => ListWorkshopMaps(player));
        AddCommand("css_listmaps", "List all workshop maps from maplist", (player, _) => ListWorkshopMaps(player));
        AddCommand("css_maplist", "List all workshop maps from maplist", (player, _) => ListWorkshopMaps(player));
        AddCommand("css_changemap", "Force change to a workshop map (admin only)", (player, info) => ForceChangeMap(player, info));

        _rtvEnabled = false;
        float delaySeconds = _cfg.RTVDelay * 60.0f;
        _rtvEnabledAt = DateTime.UtcNow.AddSeconds(delaySeconds);

        if (delaySeconds <= 0)
        {
            _rtvEnabled = true;
        }
        else
        {
            AddTimer(delaySeconds, () =>
            {
                _rtvEnabled = true;
                ChatAllTr(Tr.RtvAvailable);
            });
        }

        CalculateVoteTime();

        SetupConfigWatcher();

        Logger.LogInformation("[uf-mapchoose] Loaded with {Count} maps", _mapList.Count);
    }

    public override void Unload(bool hotReload)
    {
        _configWatcher?.Dispose();
        _configWatcher = null;
    }

    private void CalculateVoteTime()
    {
        var cvar = ConVar.Find("mp_timelimit");
        float timeLimit = cvar?.GetPrimitiveValue<float>() ?? 0;

        if (timeLimit > 0)
        {
            float preVoteDuration = 60.0f;
            float voteDuration = _cfg.VoteDuration;
            float totalVotePhase = preVoteDuration + voteDuration;
            float totalSeconds = timeLimit * 60.0f;

            if (totalSeconds > totalVotePhase)
            {
                float triggerAt = totalSeconds - totalVotePhase;
                AddTimer(triggerAt, () =>
                {
                    _voteTimeElapsed = true;
                });
            }
        }
    }

    private void SetupConfigWatcher()
    {
        var configPath = Path.GetFullPath(Path.Combine(ModuleDirectory, "../../configs/plugins/uf-mapchoose/config.cfg"));
        var dir = Path.GetDirectoryName(configPath);
        if (dir == null || !Directory.Exists(dir)) return;

        _configWatcher = new FileSystemWatcher(dir, "config.cfg")
        {
            NotifyFilter = NotifyFilters.LastWrite,
            EnableRaisingEvents = true
        };

        _configWatcher.Changed += (_, _) =>
        {
            Server.NextFrame(() =>
            {
                LoadConfig();
                Logger.LogInformation("[uf-mapchoose] config.cfg reloaded.");
            });
        };
    }

    private void LoadConfig()
    {
        var configPath = Path.Combine(ModuleDirectory, "../../configs/plugins/uf-mapchoose/config.cfg");

        if (!File.Exists(configPath))
        {
            Logger.LogWarning("[uf-mapchoose] config.cfg not found, using defaults.");
            return;
        }

        try
        {
            var json = File.ReadAllText(configPath);
            _cfg = JsonSerializer.Deserialize<PluginConfig>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }) ?? new PluginConfig();
        }
        catch (Exception ex)
        {
            Logger.LogError("[uf-mapchoose] Failed to parse config.cfg: {Error}", ex.Message);
        }
    }

    private void LoadMapList()
    {
        _mapList.Clear();
        var configPath = Path.Combine(ModuleDirectory, "../../configs/plugins/uf-mapchoose/maplist.cfg");

        if (!File.Exists(configPath))
        {
            Logger.LogWarning("[uf-mapchoose] maplist.cfg not found at {Path}", configPath);
            return;
        }

        foreach (var line in File.ReadAllLines(configPath))
        {
            var trimmed = line.Trim();
            if (string.IsNullOrEmpty(trimmed) || trimmed.StartsWith("//"))
                continue;

            var parts = trimmed.Split(':', 2);
            if (parts.Length == 2)
            {
                var mapName = parts[0].Trim();
                var workshopId = new string(parts[1].Trim().Where(char.IsDigit).ToArray());
                if (!string.IsNullOrEmpty(workshopId))
                    _mapList.Add(new MapInfo(mapName, workshopId));
            }
        }

        Logger.LogInformation("[uf-mapchoose] Loaded {Count} maps", _mapList.Count);
    }

    private void LoadRecentMaps()
    {
        if (_cfg.ExcludeMaps <= 0) return;
        _recentMaps.Clear();
        var path = Path.Combine(ModuleDirectory, "recent_maps.txt");
        if (!File.Exists(path)) return;

        foreach (var line in File.ReadAllLines(path))
        {
            var trimmed = line.Trim();
            if (!string.IsNullOrEmpty(trimmed))
                _recentMaps.Enqueue(trimmed);
        }
    }

    private void LoadTranslations()
    {
        _translations.Clear();
        var langDir = Path.Combine(ModuleDirectory, "lang");
        if (!Directory.Exists(langDir))
        {
            Logger.LogWarning("[uf-mapchoose] lang directory not found at {Path}", langDir);
            return;
        }

        foreach (var file in Directory.GetFiles(langDir, "*.json"))
        {
            var langCode = Path.GetFileNameWithoutExtension(file);
            try
            {
                var json = File.ReadAllText(file);
                var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(json);
                if (dict != null)
                    _translations[langCode] = dict;
            }
            catch (Exception ex)
            {
                Logger.LogError("[uf-mapchoose] Failed to load lang file {File}: {Error}", file, ex.Message);
            }
        }

        Logger.LogInformation("[uf-mapchoose] Loaded {Count} languages", _translations.Count);
    }

    private void SaveRecentMaps()
    {
        if (_cfg.ExcludeMaps <= 0) return;
        File.WriteAllLines(Path.Combine(ModuleDirectory, "recent_maps.txt"), _recentMaps);
    }

    private void TrackCurrentMap()
    {
        if (_cfg.ExcludeMaps <= 0) return;
        string currentMap = Server.MapName;
        if (string.IsNullOrEmpty(currentMap)) return;

        if (!_recentMaps.Contains(currentMap))
            _recentMaps.Enqueue(currentMap);

        while (_recentMaps.Count > _cfg.ExcludeMaps)
            _recentMaps.Dequeue();

        SaveRecentMaps();
    }

    [ConsoleCommand("css_nominate", "Nominate a map for the vote")]
    [ConsoleCommand("css_nom", "Nominate a map for the vote")]
    public void OnNominate(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        if (_preVoteInProgress || _voteInProgress) { ChatTr(player, Tr.VoteInProgress); return; }
        if (_mapChangePending) { ChatTr(player, Tr.MapChangePending); return; }
        if (_mapList.Count == 0) { ChatTr(player, Tr.NoMapsConfigured); return; }

        var arg = command.GetArg(1);

        if (!string.IsNullOrEmpty(arg))
        {
            MapInfo? selected;
            if (int.TryParse(arg, out int num) && num >= 1 && num <= _mapList.Count)
                selected = _mapList[num - 1];
            else
                selected = _mapList.FirstOrDefault(m => m.MapName.Contains(arg, StringComparison.OrdinalIgnoreCase));

            if (selected == null)
            {
                ChatTr(player, Tr.MapNotFound, arg);
                return;
            }

            _nominatePages.Remove(player.SteamID);
            _nominations[player.SteamID] = selected.MapName;
            ChatAllTr(Tr.NominateBroadcast, player.PlayerName, selected.MapName);
            return;
        }

        _nominatePages[player.SteamID] = 0;
        ShowNominatePage(player, 0);
    }

    private void ShowNominatePage(CCSPlayerController player, int page)
    {
        int totalPages = Math.Max(1, (int)Math.Ceiling(_mapList.Count / 5.0));
        int start = page * 5;

        ChatTr(player, Tr.NominateHeader, page + 1, totalPages);
        for (int i = 0; i < 5; i++)
        {
            int idx = start + i;
            string label = idx < _mapList.Count ? _mapList[idx].MapName : "---";
            string color = idx < _mapList.Count ? "\x04" : "\x08";
            player.PrintToChat($"  \x05!{i + 1}\x01  {color}{label}\x01");
        }

        string nextColor = page < totalPages - 1 ? "\x05" : "\x08";
        string backColor = page > 0 ? "\x05" : "\x08";
        player.PrintToChat($"  {nextColor}!6\x01  Next Page \x01→   {backColor}!7\x01  ← Back   \x05!8\x01  Close");
    }

    private void HandleNumberCommand(CCSPlayerController? player, int number)
    {
        if (player == null || !player.IsValid) return;

        if (_nominatePages.TryGetValue(player.SteamID, out int page))
        {
            int totalPages = Math.Max(1, (int)Math.Ceiling(_mapList.Count / 5.0));

            switch (number)
            {
                case >= 1 and <= 5:
                    int mapIndex = page * 5 + (number - 1);
                    if (mapIndex >= _mapList.Count) { ChatTr(player, Tr.InvalidSelection); return; }
                    var map = _mapList[mapIndex];
                    _nominatePages.Remove(player.SteamID);
                    _nominations[player.SteamID] = map.MapName;
                    ChatAllTr(Tr.NominateBroadcast, player.PlayerName, map.MapName);
                    break;
                case 6:
                    if (page >= totalPages - 1) { ChatTr(player, Tr.LastPage); return; }
                    _nominatePages[player.SteamID] = page + 1;
                    ShowNominatePage(player, page + 1);
                    break;
                case 7:
                    if (page <= 0) { ChatTr(player, Tr.FirstPage); return; }
                    _nominatePages[player.SteamID] = page - 1;
                    ShowNominatePage(player, page - 1);
                    break;
                case 8:
                    _nominatePages.Remove(player.SteamID);
                    ChatTr(player, Tr.NominateClosed);
                    break;
                default:
                    CastVote(player, number);
                    break;
            }
            return;
        }

        CastVote(player, number);
    }

    [ConsoleCommand("css_rtv", "Rock the vote to change the map")]
    [ConsoleCommand("css_rockthevote", "Rock the vote to change the map")]
    public void OnRtv(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        if (!_cfg.AllowRtv) { ChatTr(player, Tr.RtvDisabled); return; }
        if (_preVoteInProgress || _voteInProgress) { ChatTr(player, Tr.VoteInProgress); return; }
        if (_mapChangePending) { ChatTr(player, Tr.MapChangePending); return; }

        if (!_rtvEnabled)
        {
            int remaining = (int)Math.Ceiling((_rtvEnabledAt - DateTime.UtcNow).TotalSeconds);
            ChatTr(player, Tr.RtvWait, Math.Max(0, remaining));
            return;
        }

        if (_rtvVotes.Contains(player.SteamID))
        {
            ChatTr(player, Tr.RtvAlreadyVoted);
            return;
        }

        _rtvVotes.Add(player.SteamID);
        int needed = GetRtvThreshold();
        ChatAllTr(Tr.RtvBroadcast, player.PlayerName, _rtvVotes.Count, needed);

        if (_rtvVotes.Count >= needed)
        {
            _isRtvVote = true;
            TriggerPreVote();
        }
    }

    [ConsoleCommand("css_unrtv", "Cancel your RTV vote")]
    public void OnUnRtv(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        if (_preVoteInProgress || _voteInProgress) { ChatTr(player, Tr.VoteInProgress); return; }

        if (!_rtvVotes.Remove(player.SteamID))
        {
            ChatTr(player, Tr.RtvNotVoted);
            return;
        }

        int needed = GetRtvThreshold();
        ChatAllTr(Tr.RtvCancelled, player.PlayerName, _rtvVotes.Count, needed);
    }

    [ConsoleCommand("css_revote", "Change your vote during an active map vote")]
    public void OnRevote(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;
        if (!_voteInProgress) { ChatTr(player, Tr.NoVoteActive); return; }

        if (_playerVotes.TryGetValue(player.SteamID, out int prev))
            ChatTr(player, Tr.CurrentVote, _voteOptions[prev].MapName);
        else
            ChatTr(player, Tr.NoVoteYet);

        _playerVotes.Remove(player.SteamID);
        OpenVoteHud(player);
    }

    [ConsoleCommand("css_nextmap", "Show the next map or current vote status")]
    [ConsoleCommand("css_nm", "Show the next map or current vote status")]
    public void OnNextMap(CCSPlayerController? player, CommandInfo command)
    {
        if (player == null || !player.IsValid) return;

        if (_mapChangePending && _pendingWinner != null)
        {
            ChatTr(player, Tr.NextMap, _pendingWinner.MapName);
            return;
        }

        if (_voteInProgress)
        {
            var counts = GetVoteCounts();
            ChatTr(player, Tr.VoteInProgressHeader);
            for (int i = 0; i < _voteOptions.Count; i++)
            {
                if (counts[i] > 0)
                    ChatTr(player, Tr.VoteResultWithVotes, i + 1, _voteOptions[i].MapName, counts[i]);
                else
                    ChatTr(player, Tr.VoteResultNoVotes, i + 1, _voteOptions[i].MapName);
            }
            return;
        }

        ChatTr(player, Tr.NoMapPending);
    }

    private void CastVote(CCSPlayerController? player, int option) // 1-based (!1-!9 fallback)
    {
        if (option < 1 || option > _voteOptions.Count) return;
        CastVoteByIndex(player, option - 1);
    }

    private void CastVoteByIndex(CCSPlayerController? player, int index) // 0-based (HUD menu)
    {
        if (player == null || !player.IsValid || !_voteInProgress) return;
        if (index < 0 || index >= _voteOptions.Count) return;

        bool changing = _playerVotes.ContainsKey(player.SteamID);
        _playerVotes[player.SteamID] = index;

        string mapName = _voteOptions[index].MapName;
        ChatTr(player, Tr.VotedFor, mapName);

        if (changing)
            ChatAllTr(Tr.ChangedVote, player.PlayerName, mapName);
    }

    private void StartVote()
    {
        if (_voteInProgress) return;
        _voteInProgress = true;
        _playerVotes.Clear();
        _voteOptions = BuildVoteOptions();

        if (_voteOptions.Count == 0)
        {
            ChatAllTr(Tr.NoMapsAvailable);
            _voteInProgress = false;
            return;
        }

        _voteTimeLeft = 15;
        ChatAllTr(Tr.VoteStarted, 15);

        foreach (var p in Utilities.GetPlayers().Where(p => p.IsValid && !p.IsBot))
            OpenVoteHud(p);

        _voteTimer = AddTimer(1.0f, VoteTick, TimerFlags.REPEAT);
    }

    private void VoteTick()
    {
        _voteTimeLeft--;

        if (_voteTimeLeft <= 0)
        {
            EndVote();
            return;
        }

        if (_voteTimeLeft is 10 or 5 or 3 or 2 or 1)
            ChatAllTr(Tr.VoteEndsIn, _voteTimeLeft);

        foreach (var p in Utilities.GetPlayers().Where(p => p.IsValid && !p.IsBot))
            OpenVoteHud(p);
    }

    private void EndVote()
    {
        _voteTimer?.Kill();
        _voteTimer = null;
        _voteInProgress = false;

        if (_voteOptions.Count == 0)
        {
            PlaySoundToAll(SoundVoteFailure);
            ChatAllTr(Tr.NoMapsAvailable);
            return;
        }

        var totalVotes = _playerVotes.Count;
        if (totalVotes == 0)
        {
            PlaySoundToAll(SoundVoteFailure);
            ChatAllTr(Tr.VoteFailedNoVotes);
            return;
        }

        var counts = new int[_voteOptions.Count];
        foreach (var v in _playerVotes.Values)
            counts[v]++;

        int maxVotes = counts.Max();
        var winners = Enumerable.Range(0, _voteOptions.Count)
            .Where(i => counts[i] == maxVotes)
            .Select(i => _voteOptions[i])
            .ToList();

        var winner = winners[Random.Shared.Next(winners.Count)];

        ChatAllTr(Tr.MapWon, winner.MapName);
        for (int i = 0; i < _voteOptions.Count; i++)
        {
            if (counts[i] > 0)
                ChatAllTr(Tr.VoteResultWithVotes, i + 1, _voteOptions[i].MapName, counts[i]);
        }

        _nominations.Clear();
        _rtvVotes.Clear();

        if (winner.WorkshopId == "extend")
        {
            _isRtvVote = false;
            PlaySoundToAll(SoundVoteFailure);
            _extendCount++;
            var cvar = ConVar.Find("mp_timelimit");
            float current = cvar?.GetPrimitiveValue<float>() ?? 0;
            Server.ExecuteCommand($"mp_timelimit {current + _cfg.ExtendTimeStep}");
            ChatAllTr(Tr.MapExtended, _cfg.ExtendTimeStep, _extendCount, _cfg.ExtendLimit);
            return;
        }

        PlaySoundToAll(SoundVoteSuccess);
        _pendingWinner = winner;
        _mapChangePending = true;

        if (_cfg.ChangeMapAfterRoundEnd)
        {
            ChatAllTr(Tr.ChangeAfterRound);
            AddTimer(60.0f, () =>
            {
                if (_mapChangePending && _pendingWinner != null)
                {
                    Logger.LogWarning("[uf-mapchoose] Round did not end within 60 seconds, forcing map change.");
                    ChatAllTr(Tr.MapChangeTimeout);
                    Server.NextWorldUpdate(() => ExecuteMapChange());
                }
            });
        }
        else
        {
            ChatAllTr(Tr.MapChangeSoon, winner.MapName);
            AddTimer(3.0f, () => Server.NextWorldUpdate(() => ExecuteMapChange()));
        }
    }

    private void TriggerPreVote()
    {
        if (_preVoteInProgress || _voteInProgress || _mapChangePending) return;
        _preVoteInProgress = true;
        _preVoteTimeLeft = 60;

        ChatAllTr(Tr.PreVoteStart, 60);
        PlaySoundToAll(PreVoteSounds[60]);

        _preVoteTimer = AddTimer(1.0f, PreVoteTick, TimerFlags.REPEAT);
    }

    private void PreVoteTick()
    {
        _preVoteTimeLeft--;

        if (PreVoteSounds.TryGetValue(_preVoteTimeLeft, out string? sound))
        {
            PlaySoundToAll(sound);
            if (_preVoteTimeLeft is 30 or 10)
                ChatAllTr(Tr.VoteStartsIn, _preVoteTimeLeft);
        }

        if (_preVoteTimeLeft <= 0)
        {
            _preVoteTimer?.Kill();
            _preVoteTimer = null;
            _preVoteInProgress = false;
            PlaySoundToAll(SoundVoteStarted);
            StartVote();
        }
    }

    private void PlaySoundToAll(string sound)
    {
        foreach (var p in Utilities.GetPlayers().Where(p => p.IsValid && !p.IsBot))
            p.ExecuteClientCommand($"play {sound} 0.05");
    }

    private void ExecuteMapChange()
    {
        if (_pendingWinner == null)
        {
            Logger.LogWarning("[uf-mapchoose] ExecuteMapChange called but _pendingWinner is null.");
            return;
        }

        string mapName = _pendingWinner.MapName;
        string workshopId = _pendingWinner.WorkshopId;

        Logger.LogInformation("[uf-mapchoose] Executing map change to {Map} (WorkshopID: {Id})", mapName, workshopId);
        TrackCurrentMap();

        _pendingWinner = null;
        _mapChangePending = false;

        Server.NextWorldUpdate(() =>
        {
            _isRtvVote = false;

            if (Server.IsMapValid(mapName))
            {
                Logger.LogInformation("[uf-mapchoose] Standard map detected, using changelevel");
                Server.ExecuteCommand($"changelevel {mapName}");
            }
            else if (!string.IsNullOrEmpty(workshopId) && ulong.TryParse(workshopId, out _))
            {
                Logger.LogInformation("[uf-mapchoose] Workshop map detected, using host_workshop_map {Id}", workshopId);
                Server.ExecuteCommand($"host_workshop_map {workshopId}");
            }
            else
            {
                Logger.LogInformation("[uf-mapchoose] Falling back to ds_workshop_changelevel for {Map}", mapName);
                Server.ExecuteCommand($"ds_workshop_changelevel {mapName}");
            }
        });
    }

    private List<MapInfo> BuildVoteOptions()
    {
        var options = new List<MapInfo>();
        string currentMap = Server.MapName;

        if (_nominations.Count == 0)
        {
            var pool = _mapList
                .Where(m => IsMapEligible(m, currentMap))
                .OrderBy(_ => Random.Shared.Next())
                .Take(_cfg.IncludeMaps)
                .ToList();

            options.AddRange(pool);
        }
        else
        {
            foreach (var name in _nominations.Values.Distinct())
            {
                if (options.Count >= _cfg.IncludeMaps) break;
                var map = _mapList.FirstOrDefault(m => m.MapName == name);
                if (map != null && !options.Contains(map) && IsMapEligible(map, currentMap))
                    options.Add(map);
            }

            var pool = _mapList
                .Where(m => !options.Contains(m) && IsMapEligible(m, currentMap))
                .OrderBy(_ => Random.Shared.Next())
                .ToList();

            while (options.Count < _cfg.IncludeMaps && pool.Count > 0)
            {
                options.Add(pool[0]);
                pool.RemoveAt(0);
            }
        }

        if (_cfg.IncludeCurrent)
        {
            var current = _mapList.FirstOrDefault(m => m.MapName.Equals(currentMap, StringComparison.OrdinalIgnoreCase));
            if (current != null && !options.Contains(current))
                options.Insert(0, current);
        }

        if (_cfg.AllowExtend && _extendCount < _cfg.ExtendLimit)
            options.Add(new MapInfo($"Extend +{_cfg.ExtendTimeStep}m", "extend"));

        return options;
    }

    private bool IsMapEligible(MapInfo map, string currentMap)
    {
        if (!_cfg.IncludeCurrent && map.MapName.Equals(currentMap, StringComparison.OrdinalIgnoreCase))
            return false;
        if (_cfg.ExcludeMaps > 0 && _recentMaps.Contains(map.MapName))
            return false;
        return true;
    }

    private void ListWorkshopMaps(CCSPlayerController? player)
    {
        if (_mapList.Count == 0)
        {
            if (player != null)
                ChatTr(player, Tr.NoMapsConfigured);
            else
                Logger.LogWarning("[uf-mapchoose] No workshop maps configured.");
            return;
        }

        if (player != null)
        {
            ChatTr(player, Tr.ListMapsHeader, _mapList.Count);
            for (int i = 0; i < _mapList.Count; i++)
            {
                var map = _mapList[i];
                player.PrintToChat($"  \x05{i + 1}.\x01 {map.MapName} \x08(Workshop: {map.WorkshopId})\x01");
            }
        }
        else
        {
            Logger.LogInformation("[uf-mapchoose] Workshop maps ({Count} total):", _mapList.Count);
            foreach (var map in _mapList)
            {
                Logger.LogInformation("  {Name} (Workshop: {Id})", map.MapName, map.WorkshopId);
            }
        }
    }

    private void ForceChangeMap(CCSPlayerController? player, CommandInfo info)
    {
        var arg = info.GetArg(1);
        if (string.IsNullOrEmpty(arg))
        {
            if (player != null)
                ChatTr(player, Tr.ChangemapUsage);
            return;
        }

        MapInfo? target = null;
        if (ulong.TryParse(arg, out ulong wid))
            target = _mapList.FirstOrDefault(m => m.WorkshopId == wid.ToString());
        else
            target = _mapList.FirstOrDefault(m => m.MapName.Contains(arg, StringComparison.OrdinalIgnoreCase));

        if (target == null)
        {
            if (player != null)
                ChatTr(player, Tr.MapNotFound, arg);
            return;
        }

        ChatAllTr(Tr.AdminChangemap, target.MapName);
        Logger.LogInformation("[uf-mapchoose] Force map change to {Map} (WorkshopID: {Id})", target.MapName, target.WorkshopId);

        Server.NextWorldUpdate(() =>
        {
            if (Server.IsMapValid(target.MapName))
                Server.ExecuteCommand($"changelevel {target.MapName}");
            else if (!string.IsNullOrEmpty(target.WorkshopId) && ulong.TryParse(target.WorkshopId, out _))
                Server.ExecuteCommand($"host_workshop_map {target.WorkshopId}");
            else
                Server.ExecuteCommand($"ds_workshop_changelevel {target.MapName}");

            Logger.LogInformation("[uf-mapchoose] Force workshop changelevel sent: {Id}", target.WorkshopId);
        });
    }

    private void OpenVoteHud(CCSPlayerController player)
    {
        var menu = new CenterHtmlMenu($"[uf-mapchoose] Vote! ({_voteTimeLeft}s)", this);
        menu.ExitButton = false;

        var counts = GetVoteCounts();
        _playerVotes.TryGetValue(player.SteamID, out int currentVote);
        bool hasVoted = _playerVotes.ContainsKey(player.SteamID);

        for (int i = 0; i < _voteOptions.Count; i++)
        {
            int idx = i;
            string star = hasVoted && currentVote == i ? "★ " : "";
            string label = $"{star}{_voteOptions[i].MapName} [{counts[i]}]";
            menu.AddItem(label, (p, opt) =>
            {
                opt.PostSelectAction = PostSelectAction.Close;
                CastVoteByIndex(p, idx);
            });
        }

        menu.Display(player, _voteTimeLeft);
    }

    private int[] GetVoteCounts()
    {
        var counts = new int[_voteOptions.Count];
        foreach (var v in _playerVotes.Values)
            if (v >= 0 && v < counts.Length)
                counts[v]++;
        return counts;
    }

    private int GetRtvThreshold()
    {
        var players = Utilities.GetPlayers().Where(p => p.IsValid && !p.IsBot);
        if (_cfg.IgnoreSpec)
            players = players.Where(p => p.TeamNum >= 2);
        return Math.Max(1, (int)Math.Ceiling(players.Count() * _cfg.RTVPercent));
    }

     private void Chat(CCSPlayerController player, string message)
         => player.PrintToChat($" \x01[\x04uf-mapchoose\x01] {message}");

     private void ChatTr(CCSPlayerController player, string trKey, params object[] args)
         => player.PrintToChat($" \x01[\x04uf-mapchoose\x01] {TrMsg(trKey, GetPlayerLanguage(player.SteamID), args)}");

     private void ChatAll(string message)
         => Server.PrintToChatAll($" \x01[\x04uf-mapchoose\x01] {message}");

     private void ChatAllTr(string trKey, params object[] args)
     {
         foreach (var p in Utilities.GetPlayers().Where(p => p.IsValid && !p.IsBot))
             p.PrintToChat($" \x01[\x04uf-mapchoose\x01] {TrMsg(trKey, GetPlayerLanguage(p.SteamID), args)}");
     }

    private HookResult OnPlayerDisconnect(EventPlayerDisconnect @event, GameEventInfo info)
    {
        if (@event.Userid == null || !@event.Userid.IsValid) return HookResult.Continue;
        ulong steamId = @event.Userid.SteamID;
        _rtvVotes.Remove(steamId);
        _nominations.Remove(steamId);
        _nominatePages.Remove(steamId);
        _playerLanguages.TryRemove(steamId, out _);

        if (_rtvEnabled && !_preVoteInProgress && !_voteInProgress && !_mapChangePending && _rtvVotes.Count > 0)
        {
            int needed = GetRtvThreshold() - 1;
            if (_rtvVotes.Count >= needed)
            {
                _isRtvVote = true;
                TriggerPreVote();
            }
        }

        return HookResult.Continue;
    }

    private HookResult OnPlayerConnectFull(EventPlayerConnectFull @event, GameEventInfo info)
    {
        if (@event.Userid == null || !@event.Userid.IsValid) return HookResult.Continue;
        var player = @event.Userid;
        ulong steamId = player.SteamID;

        if (_playerLanguages.ContainsKey(steamId)) return HookResult.Continue;

        string ipAddress = player.IpAddress ?? "";
        int portIdx = ipAddress.LastIndexOf(':');
        string ip = portIdx > 0 ? ipAddress[..portIdx] : ipAddress;

        if (!string.IsNullOrEmpty(ip) && ip != "0.0.0.0" && ip != "loopback")
        {
            AddTimer(0.5f, () => DetectPlayerLanguage(steamId, ip));
        }

        return HookResult.Continue;
    }

    private async void DetectPlayerLanguage(ulong steamId, string ip)
    {
        try
        {
            var response = await _httpClient.GetStringAsync($"http://ip-api.com/json/{ip}?fields=countryCode");
            var doc = JsonDocument.Parse(response);
            string countryCode = doc.RootElement.GetProperty("countryCode").GetString() ?? "";

            if (CountryToLanguage.TryGetValue(countryCode, out string? lang))
                _playerLanguages[steamId] = lang;
        }
        catch
        {
            // silently fall back to default language
        }
    }

    private string GetPlayerLanguage(ulong steamId)
    {
        return _playerLanguages.TryGetValue(steamId, out string? lang) ? lang : _cfg.DefaultLanguage;
    }

    private HookResult OnRoundEnd(EventRoundEnd @event, GameEventInfo info)
    {
        if (_mapChangePending && _pendingWinner != null)
        {
            Logger.LogInformation("[uf-mapchoose] Round ended, executing map change to {Map} (WorkshopID: {Id})", _pendingWinner.MapName, _pendingWinner.WorkshopId);
            Server.NextWorldUpdate(() => ExecuteMapChange());
        }
        else if (!_preVoteInProgress && !_voteInProgress && !_mapChangePending)
        {
            CheckAndTriggerPreVote();
        }
        return HookResult.Continue;
    }

    private HookResult OnMapShutdown(EventMapShutdown @event, GameEventInfo info)
    {
        if (_mapChangePending && _pendingWinner != null)
        {
            Logger.LogInformation("[uf-mapchoose] Map shutdown detected, executing map change to {Map} (WorkshopID: {Id})", _pendingWinner.MapName, _pendingWinner.WorkshopId);
            Server.NextWorldUpdate(() => ExecuteMapChange());
        }
        return HookResult.Continue;
    }

    private HookResult OnRoundStart(EventRoundStart @event, GameEventInfo info)
    {
        if (_voteTimeElapsed && !_preVoteInProgress && !_voteInProgress && !_mapChangePending)
            CheckAndTriggerPreVote();
        return HookResult.Continue;
    }

    private void CheckAndTriggerPreVote()
    {
        if (_preVoteInProgress || _voteInProgress || _mapChangePending) return;
        if (!_voteTimeElapsed) return;

        if (_mapList.Count == 0) return;

        _voteTimeElapsed = false;
        TriggerPreVote();
    }
}
